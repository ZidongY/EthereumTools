import coincurve

def verify(key):
    private_key = key
    pubilc_key = coincurve.PrivateKey.from_hex(private_key).public_key.format(False)
    print('\nCurrent Private Key is: ' + '0x' + private_key)
    print('pubilc_key_uncompressed:'+'0x'+ pubilc_key.hex())

    data = input('Please input hexadecimal raw data [before signature]: \n>')
    sign = input('Please input hexadecimal ECDSA Signature [starting with 30]: \n> ')
    for i in range(3):
        if len(sign) <140 or len(sign) >144 :
            print('\nThe input signature length Error! (should be 70-72 bytes)')
            sign = input('Please input again [%s]:' % (3 - i))
        else:
            break
    result = coincurve.verify_signature(bytes.fromhex(sign),bytes.fromhex(data),pubilc_key,hasher=None)
    print('\nVerification Results : ',result)
    return input('\nPress Enter continue ...')