import coincurve
import hash

def sign( key ):
    private_key = key
    print('\nCurrent Private Key is: '+'0x'+private_key)
    data = input('Please input hexadecimal signature data: \n>')
    flag = input('Please select Hash Digest algorithm: 1-None  2-Keccak256  3-sha256 \n>')
    if flag == '1':
        for i in range(3):
            if len(data) != 64:
                print('\nThe input data length Error! (should be 32 bytes)')
                data = input('Please input again [%s]: \n>' %(3-i))
            else:
                break
        if len(data) == 64:
            msg = bytes.fromhex(data)
            signature1 = coincurve.PrivateKey.from_hex(private_key).sign(msg,hasher=None)
            signature2 = coincurve.PrivateKey.from_hex(private_key).sign_recoverable(msg,hasher=None)
            print('Signature result [Format 1]: '+'0x'+signature1.hex())
            print('Signature result [Format 2]: '+'0x'+signature2.hex())
            return input('\nPress Enter continue ...')
        else:
            return print('Too many input times. Back to main Menu')
    if flag == '2':
        msg = hash.keccak256(bytes.fromhex(data))
        signature1 = coincurve.PrivateKey.from_hex(private_key).sign(msg, hasher=None)
        signature2 = coincurve.PrivateKey.from_hex(private_key).sign_recoverable(msg, hasher=None)
        print('Signature result [Format 1]: '+'0x'+signature1.hex())
        print('Signature result [Format 2]: '+'0x'+signature2.hex())
        return input('\nPress Enter continue ...')
    if flag == '3':
        msg = hash.sha256(bytes.fromhex(data))
        signature1 = coincurve.PrivateKey.from_hex(private_key).sign(msg, hasher=None)
        signature2 = coincurve.PrivateKey.from_hex(private_key).sign_recoverable(msg, hasher=None)
        print('Signature result [Format 1]: '+'0x'+signature1.hex())
        print('Signature result [Format 2]: '+'0x'+signature2.hex())
        return input('\nPress Enter continue ...')
