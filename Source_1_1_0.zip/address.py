import coincurve

import hash


def export( key ):
    # 私钥赋值
    private_key = key

    #计算公钥
    pubilc_key_uncompressed = coincurve.PrivateKey.from_hex(private_key).public_key.format(False)
    pubilc_key_compressed = coincurve.PrivateKey.from_hex(private_key).public_key.format()
    pubilc_key_point = coincurve.PublicKey(pubilc_key_compressed).point()
    pubilc_key_point_hex = list(pubilc_key_point)
    for i in range(len(pubilc_key_point_hex)):
       pubilc_key_point_hex[i] = hex(pubilc_key_point_hex[i])[2:]

    print('\nCurrent Private Key is: '+'0x'+private_key)
    print('\nGenerate Public Key:')
    print('[uncompressed]：'+'0x'+pubilc_key_uncompressed.hex())
    print('[compressed]：'+'0x'+pubilc_key_compressed.hex())
    print('[point]：', pubilc_key_point)
    print('[point_hex]：',pubilc_key_point_hex)

    #导出地址
    addr = hash.keccak256(pubilc_key_uncompressed[1:])[-20:]
    print('\nTips: Export addresses using public keys[uncompressed]',)
    print('Account Address: '+'0x'+addr.hex())
    return input('\nPress Enter continue ...')