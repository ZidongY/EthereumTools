import address
import hash
import tx_classic
import tx_eip155
import sign_ECDSA
import sign_Verify

print("""
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::            Welcome to use the Ethereum Tools (v1.1.0) ！              ::::
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::      Developer： Zidong.Yin                   Date：2018.09.02        ::::
::::      QQ：271784423                                                    ::::
::::      Email：yinzidong2003@163.com                                     ::::
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::      Help you verify the various types of data in the blockchain!     ::::
:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
""")

private_key = '4646464646464646464646464646464646464646464646464646464646464646'
select_item = 1

while select_item:
    print('\nCurrent private key: '+'0x'+private_key)
    print('\nPress Number , Enter Function:')
    print('1 - Set the account private key.')
    print('2 - Generate account ECC public key / Ethereum Address.')
    print('3 - Verifying Keccak256 calculation results.')
    print('4 - Generate Transaction messages [Old Style].')
    print('5 - Generate Transaction messages [EIP-155].')
    print('6 - Calculate ECDSA Signature Data.')
    print('7 - Verifying ECDSA Signature Data.')
    print('\n0 - Exit Tools.')

    select_item = int(input('> '))
    if select_item == 0:
        break
    if select_item == 1:
        data = input('\nPlease input a hexadecimal private key :\n>')
        for i in range(3):
            if len(data)!=64 :
                print('Length of private key is error.')
                data = input('Please input again [%s]:' % (3-i))
            else:
                private_key = data
                break
        continue
    if select_item == 2:
        address.export(private_key)
        continue
    if select_item == 3:
        data = input('\nPlease input hexadecimal data :\n>')
        for i in range(3):
            if len(data)%2!=0:
                print('Input data Format error.')
                data = input('Please input again [%s]:' % (3 - i))
            else:
                msg_hash = hash.keccak256(bytes.fromhex(data))
                print('Keccak256 Value is : ', msg_hash.hex())
                break
        input('\nPress Enter continue ...')
        continue
    if select_item == 4:
        tx_classic.raw_transaction_hex(private_key)
        continue
    if select_item == 5:
        tx_eip155.raw_transaction_hex(private_key)
        continue
    if select_item == 6:
        sign_ECDSA.sign(private_key)
        continue
    if select_item == 7:
        sign_Verify.verify(private_key)
        continue

    else:
        print('Please enter the correct number!')
        continue


