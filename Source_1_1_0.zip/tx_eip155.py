#"Spurious Dragon"硬分叉后，太坊交易数据生成方法
import coincurve

import convert
import hash
import rlp_encode


def raw_transaction_hex(key):
    print('Hard fork : "Spurious Dragon".')
    print('https://github.com/ethereum/EIPs/blob/master/EIPS/eip-155.md')
    print('Scope: 1. CHAIN_ID = 1 (Main net)')
    print(' '*7+'2. block.number >= 2,675,000')
    print('Sample：[ nonce=9 , gasprice=20 Gwei , gaslimit=21000 , to= 0x3535353535353535353535353535353535353535 , value=1 ether , data=null , v=chain_id=1 , r=null , s=null]')
    #构建交易报文结构   fields = [ nonce , gasprice , gaslimit, to , value , data ]
    fields = ['9','20000000000','21000','0x3535353535353535353535353535353535353535','1000000000000000000','','1','','']
    tips = [ 'Nonce(default=9):  ', 'Gas price (Gwei)(default=20):  ', 'Gas limit (wei)(default=21000):  ', 'To address (default=0x3535353535353535353535353535353535353535):  ', 'Value (ETH)(default=1): ',  'Addition Data (default=null): ','v (default=1): ','r (default=null)','s (default=null)']
    #赋值各参数。
    print('------------------------------------------------------------------------------')
    print('Please enter the following data，Press Enter = null.')
    for i in range(len(fields)):
        x = input(tips[i])
        if x !='' :
            if i == 1:
                fields[i] = str(int(float(x) * 1e+9))
                continue
            if i == 4:
                fields[i] = str(int(float(x) * 1e+18))
                continue
            fields[i] = x

    print('------------------------------------------------------------------------------')
    print('Main Process Data：')
    tx_original = tuple(fields)
    print('0 - Tx_Original： ',tx_original)       #原始交易报文数据

    #将原始交易报文的各个数据进行处理，转为bytes类型。十进制数字需进行16进制转换，大端存储；0转为''。
    print('\n1 - All data converted to bytes type.')
    for i in range(len(fields)):
        fields[i] = convert.to_hexbytes(fields[i])      #各参数转为bytes类型
    print('Tx_bytes： ',fields)

    #对预处理的交易报文，进行RLP序列化处理
    print('\n2 - Serialization of pre-processed transaction messages (Tx_bytes).')
    for i in range(len(fields)):                             # 将bytes类型转为String类型，为RLP预处理。
        fields[i] = str(fields[i], 'latin1')
    tx_rlp = list(rlp_encode.rlp_encode(fields))       # RLP序列化处理。

    for i in range(len(tx_rlp)):                               #将RLP数据转为Hex String
        tx_rlp[i] = hex(ord(tx_rlp[i]))[2:].zfill(2)    #hex()转0~9数字时，会自动删掉左侧‘0’，用.zfill()固定长度，自动补零。
    tx_rlp = ''.join(tx_rlp)
    print('Tx_rlp： '+'0x'+tx_rlp)

    #对RLP数据进行kecca256哈希计算
    print('\n3 - Keccak256 Calculation of RLP data.')
    tx_Kecc256 = hash.keccak256(bytearray.fromhex(tx_rlp))
    tx_Kecc256 = list(str(tx_Kecc256,'latin1'))
    for i in range(len(tx_Kecc256)):
        tx_Kecc256[i] = hex(ord(tx_Kecc256[i]))[2:].zfill(2)
    tx_Kecc256 = ''.join(tx_Kecc256)
    print('Tx_Kecc256： 0x'+tx_Kecc256)

    # 使用Private Key针对Tx的kecca256哈希值进行ECC数字签名。
    print('\n4 - ECDSA with the private key for Tx_keccak256.')
    tx_ecdsa = coincurve.PrivateKey.from_hex(key).sign(bytes.fromhex(tx_Kecc256), hasher=None)
    tx_ecdsa_recoverable = coincurve.PrivateKey.from_hex(key).sign_recoverable(bytes.fromhex(tx_Kecc256), hasher=None)
    tx_v = tx_ecdsa_recoverable[64]+27+8+int(tx_original[-3])*2
    tx_r = int(tx_ecdsa_recoverable[:32].hex(),16)
    tx_s = int(tx_ecdsa_recoverable[32:64].hex(),16)
    print('Tx_Signature： 0x'+tx_ecdsa.hex())
    print('Tx_Signature_Recoverable： 0x'+tx_ecdsa_recoverable.hex())
    print('Tx_v: ',tx_v)
    print('Tx_r: ', tx_r)
    print('Tx_s: ', tx_s)

    # 将ECDSA签名数据中得到的v，r，s值，拼接到Tx_Original后面，得到完整交易报文。
    print('\n5 - Append  v, r and s values to Tx_Original. ')
    tx_append = list(tx_original)
    tx_append[-1] = str(tx_s)
    tx_append[-2] = str(tx_r)
    tx_append[-3] = str(tx_v)
    print('Tx_Append： ', tx_append)        # 完整交易报文

    # 对完整交易报文，再次进行RLP序列化处理，得到Raw Transaction。
    print('\n6 - And then RLP serialize the process again.)')
    for i in range(len(tx_append)):
        tx_append[i] = convert.to_hexbytes(tx_append[i])      #各参数转为bytes类型
    for i in range(len(tx_append)):                             # 将bytes类型转为String类型，为RLP预处理。
        tx_append[i] = str(tx_append[i], 'latin1')
    tx_rlp = list(rlp_encode.rlp_encode(tx_append))       # RLP序列化处理。
    for i in range(len(tx_rlp)):                               #将RLP数据转为Hex String
        tx_rlp[i] = hex(ord(tx_rlp[i]))[2:].zfill(2)    #hex()转0~9数字时，会自动删掉左侧‘0’，用.zfill()固定长度，自动补零。
    tx_raw_transaction = ''.join(tx_rlp)
    print('Raw_Transaction： 0x'+tx_raw_transaction)

    # 对Raw Transaction进行Keccak256，得到Tx_Hash。
    print('\n7 - Tx_Hash = Keccak256(Raw_Transaction).')
    tx_hash = hash.keccak256(bytearray.fromhex(tx_raw_transaction))
    print('Tx_Hash： 0x' + tx_hash.hex())

    return input('\nPress Enter continue ...')