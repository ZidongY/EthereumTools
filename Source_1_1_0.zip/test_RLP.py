import  convert
import rlp_encode

#Sample：[ nonce=9 , gasprice=20 Gwei , gaslimit=21000 , to= 0x3535353535353535353535353535353535353535 , value=1 ether , data=null , v=chain_id=1 , r=null , s=null]')
fields = ['19','5000000000','21000','0xa94f40b04c7e2217e432dfd81400a68821ce3d9d','1000000000000000000','','28','33657699389796358035596248198561631703217992287001484097387648812746161604557','105778015814320566350768120489821277637953815401908526743369793298963399446364']

#r = 31788530353447645656664577599649029782351984902934207503941108169600430881507
#s = 44456667763736015495399617182396221836703782971065017596817146528366917770492

for i in range(len(fields)):
    fields[i] = convert.to_hexbytes(fields[i])      #各参数转为bytes类型
for i in range(len(fields)):                             # 将bytes类型转为String类型，为RLP预处理。
    fields[i] = str(fields[i], 'latin1')
tx_rlp = list(rlp_encode.rlp_encode(fields))       # RLP序列化处理。
for i in range(len(tx_rlp)):                               #将RLP数据转为Hex String
    tx_rlp[i] = hex(ord(tx_rlp[i]))[2:].zfill(2)    #hex()转0~9数字时，会自动删掉左侧‘0’，用.zfill()固定长度，自动补零。
tx_raw_transaction = ''.join(tx_rlp)
print('Raw_Transaction： 0x'+tx_raw_transaction)

print(int('4A69952FF23AC444C00217321C4BAC9273266237440DEAE6599D813FBF8147CD',16))
print(int('E9DC3C3CA8EEAA16DAE8E3261B62516A56F1538162DC2328A7CDAB8D99A00F5C',16))
