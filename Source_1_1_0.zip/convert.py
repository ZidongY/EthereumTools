#将输入数据转化为16进制编码的字节数组，即比特流
def to_hexbytes(x):
    if isinstance(x, bytes):        #bytes类型保持不变
        return x
    if x.isnumeric():                 #纯数字变为16进制形式，大端存储，再转为bytes类型
        x = hex(int(x))[2:]
        if x == '0':
            return b''
        if len(x) % 2 != 0:
            x = '0'+x
        return bytearray.fromhex(x)
    if x[:2] in {'0x',b'0x'}:      #HexString转为bytes类型
        x = x[2:]
        return bytearray.fromhex(x)
    else:
        return bytearray(x,'utf-8')     #String转为bytes类型