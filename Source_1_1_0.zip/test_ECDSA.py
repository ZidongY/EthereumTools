import coincurve

private_key = '265f42d2d66a88fb66a35a0f07d278ad3e64d27e8ac7b86c39c3349e5aa4d9d3'
pubilc_key = coincurve.PrivateKey.from_hex(private_key).public_key.format(False)
print('pubilc_key_uncompressed:',pubilc_key.hex())

message = bytes.fromhex('980c367ef8c8032b73f804c5fe8741d586657e76fc51bdbba1de622679221ff9')
signature = coincurve.PrivateKey.from_hex(private_key).sign(message, hasher=None)
print('Tx_Signature： 0x'+signature.hex())


signature2 = bytes.fromhex('3045022100dfb9fb4a5b3fa8f742cd5976ae9ffaac237c890041d6d601faac980b4014a2650220552cd74f6a8573f91922497db741493794a3b22aebd3aa01f264f1ab77632783')

result = coincurve.verify_signature(signature2,message,pubilc_key,hasher=None)
print('Verify:',result)