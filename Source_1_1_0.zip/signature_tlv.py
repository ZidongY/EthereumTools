#单组数据的简易TLV拼装，返回数据类型为list[int,int,……]
def encode_tlv (x):
    if isinstance(x, bytes):
        print(1)
        value = list(x)
        if value[0] >= 128:
                value.insert(0,0)
        length = len(value)
        tag = 2
        value.insert(0,length)
        value.insert(0,tag)
        return value
    elif x.isnumeric():
        print(2)
        value = list(bytearray.fromhex(hex(int(x))[2:]))
        if value[0] >= 128:
                value.insert(0,0)
        length = len(value)
        tag = 2
        value.insert(0,length)
        value.insert(0,tag)
        return value
    elif x[:2] in {'0x', b'0x'}:
        print(3)
        value = list(bytearray.fromhex(x[2:]))
        if value[0] >= 128:
            value.insert(0, 0)
        length = len(value)
        tag = 2
        value.insert(0, length)
        value.insert(0, tag)
        return value
    else:
        return print('Format of data is error! Please add "0x"')

#通过r、s参数，拼装signature数据，返回数据类型为bytes。
def encode(r,s):
    signature = encode_tlv(r)
    signature.extend(encode_tlv(s))
    signature.insert(0,len(signature))
    signature.insert(0,48)
    return bytearray(signature).hex()

#单租数据的简易TLS解析，返回数据为[Tag ,Value, 剩余data ]，或报酬
def decode_tlv(x):
    assert isinstance(x,str)  , 'Input Data Format is Error!'
    if x[:2] in  ['0x',b'0x']:
        x = x[2:]
    data = list(bytearray.fromhex(x))
    tlv = ['','','']    #构建返回数据结构
    tlv[0] = data.pop(0)    #获取Tag
    assert tlv[0] in [48,2], 'Tag is Error!'    #判断Tag有效性
    length = data.pop(0)    #获取Length
    tlv[1] = data[:length]
    tlv[2] = data[length:]
    return tlv

#signature数据TLV解析，返回数据类型list[r=int,s=int]
def decode(x):
    tlv = decode_tlv(x)
    r,s = 1,1
    endflag = 1
    while endflag:
        assert tlv[0] in [48,2],'签名数据错误！'
        if tlv[0]==48 and tlv[2]==[]:
            tlv = decode_tlv(bytearray(tlv[1]).hex())
            continue
        if tlv[0]==2 and tlv[2]!=[]:
            if tlv[1][0]==0 and tlv[1][1]>=128:
                r = tlv[1][1:]
                tlv = decode_tlv(bytearray(tlv[2]).hex())
                continue
            else:
                r = tlv[1]
                tlv = decode_tlv(bytearray(tlv[2]).hex())
                continue
        if tlv[0]==2 and tlv[2]==[]:
            if tlv[1][0]==0 and tlv[1][1]>=128:
                s = tlv[1][1:]
                break
            else:
                s = tlv[1]
                break
    return [bytearray(r).hex(), bytearray(s).hex()]