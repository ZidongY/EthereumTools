import sha3
import hashlib

# 以太坊使用keccak-256哈希算法
def keccak256(bytes):
    k = sha3.keccak_256()
    k.update(bytes)
    return k.digest()

# SHA256摘要计算
def sha256(bytes):
    hash_value = hashlib.sha256()
    hash_value.update(bytes)
    return hash_value.hexdigest()

# RIPEMD160摘要计算
def ripemd160(bytes):
    hash_value = hashlib.new('ripemd160', bytes)
    return hash_value.hexdigest()